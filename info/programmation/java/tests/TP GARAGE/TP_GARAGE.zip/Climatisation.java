

public class Climatisation implements Option
{
	public double getPrix()
	{
		return 347.3d;
	}
	public String toString()
	{
		return "Climatisation : (347.3€)";
	}
}