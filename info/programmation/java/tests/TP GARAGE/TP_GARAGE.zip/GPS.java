

public class GPS implements Option
{
	public double getPrix()
	{
		return 113.5d;
	}
	public String toString()
	{
		return "GPS : (113.5€)";
	}
}