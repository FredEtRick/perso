

public class VitreElectrique implements Option
{
	public double getPrix()
	{
		return 212.35d;
	}
	public String toString()
	{
		return "Vitre électrique (212.35€)";
	}
}