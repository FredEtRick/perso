import java.io.Serializable;

public interface Option extends Serializable
{
	public double getPrix();
}