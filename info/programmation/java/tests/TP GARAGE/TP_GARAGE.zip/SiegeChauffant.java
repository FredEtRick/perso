

public class SiegeChauffant implements Option
{
	public double getPrix()
	{
		return 562.9d;
	}
	public String toString()
	{
		return "Siege chauffant (562.9€)";
	}
}