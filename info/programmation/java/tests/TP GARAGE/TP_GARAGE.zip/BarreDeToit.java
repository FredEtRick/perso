

public class BarreDeToit implements Option
{
	public double getPrix()
	{
		return 29.9d;
	}
	public String toString()
	{
		return "Barre de toit (29.9€)";
	}
}